import threading
counter=0
def work():
 global counter
 for _ in range(100000): counter += 1
ts=[threading.Thread(target=work) for _ in range(4)]
for t in ts: t.start()
for t in ts: t.join()
print("Без блокировки:", counter, "ожидалось 400000")

import threading
counter=0
lock=threading.Lock()
def work():
 global counter
 for _ in range(100000):
  with lock: counter += 1
ts=[threading.Thread(target=work) for _ in range(4)]
for t in ts: t.start()
for t in ts: t.join()
assert counter == 400000
print("С Lock:", counter, "проверка пройдена")

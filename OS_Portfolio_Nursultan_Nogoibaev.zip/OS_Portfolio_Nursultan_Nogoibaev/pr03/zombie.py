import os, time
pid = os.fork()
if pid == 0:
    print("Ребёнок завершился", flush=True)
    os._exit(0)
else:
    print("Родитель PID:", os.getpid(), "ребёнок PID:", pid, flush=True)
    print("В течение 15 секунд посмотрите процесс командой ps -o pid,ppid,stat,cmd -p", pid)
    time.sleep(15)
    os.wait()
    print("Родитель забрал статус ребёнка")

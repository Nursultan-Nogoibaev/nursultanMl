import signal,time,os
def handler(sig, frame): print("Получен SIGINT, программа продолжает работу")
signal.signal(signal.SIGINT,handler)
print("PID:",os.getpid(),"Нажмите Ctrl+C или отправьте kill -INT PID")
for i in range(30): print("Работаю",i); time.sleep(1)

import argparse
def read_file(path):
    data=[]
    for line in open(path, encoding="utf-8"):
        line=line.strip()
        if not line or line.startswith("#"): continue
        pid,a,b,p=line.split(); data.append(dict(pid=pid, arrival=int(a), burst=int(b), priority=int(p)))
    return data
def fcfs(ps):
    t=0; out=[]
    for p in sorted(ps,key=lambda x:(x["arrival"],x["pid"])):
        s=max(t,p["arrival"]); e=s+p["burst"]; out.append((p["pid"],s,e)); t=e
    return out
def sjf(ps):
    left=[dict(p) for p in ps]; t=0; out=[]
    while left:
        ready=[p for p in left if p["arrival"]<=t]
        if not ready: t=min(p["arrival"] for p in left); ready=[p for p in left if p["arrival"]<=t]
        p=min(ready,key=lambda x:(x["burst"],x["arrival"],x["pid"]))
        out.append((p["pid"],t,t+p["burst"])); t+=p["burst"]; left.remove(p)
    return out
def rr(ps,q):
    left={p["pid"]:p["burst"] for p in ps}; arrivals=sorted(ps,key=lambda x:(x["arrival"],x["pid"]))
    queue=[]; out=[]; t=0; i=0
    while i<len(arrivals) or queue:
        if not queue and i<len(arrivals) and t<arrivals[i]["arrival"]: t=arrivals[i]["arrival"]
        while i<len(arrivals) and arrivals[i]["arrival"]<=t: queue.append(arrivals[i]["pid"]); i+=1
        if not queue: continue
        pid=queue.pop(0); run=min(q,left[pid]); start=t; end=t+run
        while i<len(arrivals) and arrivals[i]["arrival"]<end: queue.append(arrivals[i]["pid"]); i+=1
        t=end; left[pid]-=run; out.append((pid,start,end))
        while i<len(arrivals) and arrivals[i]["arrival"]<=t: queue.append(arrivals[i]["pid"]); i+=1
        if left[pid]>0: queue.append(pid)
    return out
def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--algo",choices=["fcfs","sjf","rr"],default="fcfs"); ap.add_argument("--quantum",type=int,default=3); ap.add_argument("file"); a=ap.parse_args()
    ps=read_file(a.file); result=fcfs(ps) if a.algo=="fcfs" else sjf(ps) if a.algo=="sjf" else rr(ps,a.quantum)
    print("PID START END")
    for row in result: print(*row)
    finish={}; first={}; busy=0
    for pid,s,e in result: first.setdefault(pid,s); finish[pid]=e; busy+=e-s
    waits=[]; turns=[]; response=[]
    for p in ps:
        turn=finish[p["pid"]]-p["arrival"]; turns.append(turn); waits.append(turn-p["burst"]); response.append(first[p["pid"]]-p["arrival"])
    span=max(finish.values())-min(p["arrival"] for p in ps)
    print(f"Average waiting: {sum(waits)/len(waits):.2f}")
    print(f"Average turnaround: {sum(turns)/len(turns):.2f}")
    print(f"Average response: {sum(response)/len(response):.2f}")
    print(f"CPU utilization: {busy/span*100:.2f}%")
if __name__=="__main__": main()

import sys
name = sys.argv[1] if len(sys.argv) > 1 else "data/01.log"
with open(name, "rb") as f:
    data = f.read()
print("Файл:", name)
print("Размер:", len(data), "байт")

import threading,time
a=threading.Lock(); b=threading.Lock(); barrier=threading.Barrier(2)
def one():
 with a:
  print("Поток 1 захватил A"); barrier.wait(); print("Поток 1 ждёт B"); b.acquire()
def two():
 with b:
  print("Поток 2 захватил B"); barrier.wait(); print("Поток 2 ждёт A"); a.acquire()
threading.Thread(target=one,daemon=True).start(); threading.Thread(target=two,daemon=True).start()
time.sleep(3); print("Если потоки ждут друг друга, возник deadlock")

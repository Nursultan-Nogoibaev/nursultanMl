import threading
a=threading.Lock(); b=threading.Lock()
def work(n):
 with a:
  with b: print("Поток",n,"закончил")
ts=[threading.Thread(target=work,args=(i,)) for i in (1,2)]
for t in ts:t.start()
for t in ts:t.join()
print("Программа завершилась")

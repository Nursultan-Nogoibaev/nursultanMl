import multiprocessing as mp, time
def part_sum(values): return sum(values)
if __name__ == "__main__":
    nums = list(range(1, 1_000_001))
    chunks = [nums[i:i+250_000] for i in range(0, len(nums), 250_000)]
    start = time.perf_counter()
    with mp.Pool(4) as pool: result = pool.map(part_sum, chunks)
    print("Sum:", sum(result))
    print("Time:", round(time.perf_counter()-start, 4), "sec")

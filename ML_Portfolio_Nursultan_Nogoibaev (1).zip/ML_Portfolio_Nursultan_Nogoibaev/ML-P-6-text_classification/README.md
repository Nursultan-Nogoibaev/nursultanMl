# Практическая работа №6 — Классификация текстов

**Студент:** Нурсултан Ногойбаев Таалайбекович  
**Группа:** CS 32-24

## Цель работы
Решить задачу NLP: отличать сообщения о хоккее от сообщений о бейсболе с помощью очистки текста, TF-IDF и Multinomial Naive Bayes.

## Структура проекта
```text
ML-P-6-text_classification/
├── notebooks/
│   └── text_classification.ipynb
├── .gitignore
├── README.md
└── requirements.txt
```

## Запуск
```bash
git clone <ссылка-на-ваш-репозиторий>
cd ML-P-6-text_classification
python -m venv .venv
```

Windows:
```bash
.venv\Scripts\activate
```

macOS / Linux:
```bash
source .venv/bin/activate
```

Установка библиотек и запуск:
```bash
pip install -r requirements.txt
jupyter notebook notebooks/text_classification.ipynb
```

## Примечание
Ноутбук содержит код, пояснения и проверки. После запуска всех ячеек фактические метрики и графики будут рассчитаны на используемой версии библиотек.

# Практическая работа №1 — Разведочный анализ данных ресторана

**Студент:** Нурсултан Ногойбаев Таалайбекович  
**Группа:** CS 32-24

## Цель работы
Изучить набор данных о счетах и чаевых: проверить качество данных, исследовать распределения, сравнить дни недели и оценить связь суммы счёта с чаевыми.

## Структура проекта
```text
ML-P-1-tips_eda/
├── notebooks/
│   └── tips_eda.ipynb
├── .gitignore
├── README.md
└── requirements.txt
```

## Запуск
```bash
git clone <ссылка-на-ваш-репозиторий>
cd ML-P-1-tips_eda
python -m venv .venv
```

Windows:
```bash
.venv\Scripts\activate
```

macOS / Linux:
```bash
source .venv/bin/activate
```

Установка библиотек и запуск:
```bash
pip install -r requirements.txt
jupyter notebook notebooks/tips_eda.ipynb
```

## Примечание
Ноутбук содержит код, пояснения и проверки. После запуска всех ячеек фактические метрики и графики будут рассчитаны на используемой версии библиотек.

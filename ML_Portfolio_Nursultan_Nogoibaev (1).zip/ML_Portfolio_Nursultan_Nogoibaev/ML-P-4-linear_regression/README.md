# Практическая работа №4 — Регрессионная модель

**Студент:** Нурсултан Ногойбаев Таалайбекович  
**Группа:** CS 32-24

## Цель работы
Обучить линейную регрессию для прогнозирования чаевых, оценить качество по MAE, RMSE и R², изучить остатки и сравнить наборы признаков.

## Структура проекта
```text
ML-P-4-linear_regression/
├── notebooks/
│   └── linear_regression.ipynb
├── .gitignore
├── README.md
└── requirements.txt
```

## Запуск
```bash
git clone <ссылка-на-ваш-репозиторий>
cd ML-P-4-linear_regression
python -m venv .venv
```

Windows:
```bash
.venv\Scripts\activate
```

macOS / Linux:
```bash
source .venv/bin/activate
```

Установка библиотек и запуск:
```bash
pip install -r requirements.txt
jupyter notebook notebooks/linear_regression.ipynb
```

## Примечание
Ноутбук содержит код, пояснения и проверки. После запуска всех ячеек фактические метрики и графики будут рассчитаны на используемой версии библиотек.
